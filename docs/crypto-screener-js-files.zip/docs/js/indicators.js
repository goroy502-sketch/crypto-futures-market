/* Crypto Futures Screener - Indicator calculations
   Input candles: [{ open, high, low, close, volume }, ...]
   Candles must be ordered oldest -> newest.
*/
(function (global) {
  "use strict";

  const nums = (values) => values.map(Number).filter(Number.isFinite);

  function sma(values, period) {
    const out = Array(values.length).fill(null);
    for (let i = period - 1; i < values.length; i++) {
      const window = values.slice(i - period + 1, i + 1);
      if (window.length === period && window.every(Number.isFinite)) {
        out[i] = window.reduce((a, b) => a + b, 0) / period;
      }
    }
    return out;
  }

  function ema(values, period) {
    const out = Array(values.length).fill(null);
    if (values.length < period) return out;
    const alpha = 2 / (period + 1);
    let seed = values.slice(0, period);
    if (!seed.every(Number.isFinite)) return out;
    let previous = seed.reduce((a, b) => a + b, 0) / period;
    out[period - 1] = previous;
    for (let i = period; i < values.length; i++) {
      if (!Number.isFinite(values[i])) continue;
      previous = values[i] * alpha + previous * (1 - alpha);
      out[i] = previous;
    }
    return out;
  }

  function rsi(closes, period = 14) {
    const out = Array(closes.length).fill(null);
    if (closes.length <= period) return out;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
      const change = closes[i] - closes[i - 1];
      gains += Math.max(change, 0);
      losses += Math.max(-change, 0);
    }
    let avgGain = gains / period, avgLoss = losses / period;
    out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
    for (let i = period + 1; i < closes.length; i++) {
      const change = closes[i] - closes[i - 1];
      avgGain = (avgGain * (period - 1) + Math.max(change, 0)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.max(-change, 0)) / period;
      out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
    }
    return out;
  }

  function macd(closes, fast = 12, slow = 26, signalPeriod = 9) {
    const fastEma = ema(closes, fast), slowEma = ema(closes, slow);
    const line = closes.map((_, i) =>
      fastEma[i] == null || slowEma[i] == null ? null : fastEma[i] - slowEma[i]
    );
    // Seed the signal EMA only from the first uninterrupted run of MACD values.
    const first = line.findIndex(Number.isFinite);
    const signal = Array(line.length).fill(null);
    if (first >= 0) {
      const compact = line.slice(first);
      const compactSignal = ema(compact, signalPeriod);
      compactSignal.forEach((v, j) => { signal[first + j] = v; });
    }
    return {
      line,
      signal,
      histogram: line.map((v, i) =>
        v == null || signal[i] == null ? null : v - signal[i]
      )
    };
  }

  function bollinger(closes, period = 20, multiplier = 2) {
    const middle = sma(closes, period);
    const upper = Array(closes.length).fill(null);
    const lower = Array(closes.length).fill(null);
    for (let i = period - 1; i < closes.length; i++) {
      const window = closes.slice(i - period + 1, i + 1);
      if (middle[i] == null) continue;
      const variance = window.reduce((sum, value) => sum + (value - middle[i]) ** 2, 0) / period;
      const sd = Math.sqrt(variance);
      upper[i] = middle[i] + multiplier * sd;
      lower[i] = middle[i] - multiplier * sd;
    }
    return { upper, middle, lower };
  }

  function trueRange(candles) {
    return candles.map((c, i) => {
      const high = Number(c.high), low = Number(c.low);
      if (i === 0) return high - low;
      const prevClose = Number(candles[i - 1].close);
      return Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    });
  }

  function atr(candles, period = 14) {
    const tr = trueRange(candles);
    const out = Array(candles.length).fill(null);
    if (candles.length < period) return out;
    let value = tr.slice(0, period).reduce((a, b) => a + b, 0) / period;
    out[period - 1] = value;
    for (let i = period; i < tr.length; i++) {
      value = (value * (period - 1) + tr[i]) / period;
      out[i] = value;
    }
    return out;
  }

  function adx(candles, period = 14) {
    const length = candles.length;
    const plusDI = Array(length).fill(null), minusDI = Array(length).fill(null);
    const adxLine = Array(length).fill(null);
    if (length < period * 2) return { adx: adxLine, plusDI, minusDI };

    const tr = Array(length).fill(0), plusDM = Array(length).fill(0), minusDM = Array(length).fill(0);
    for (let i = 1; i < length; i++) {
      const up = Number(candles[i].high) - Number(candles[i - 1].high);
      const down = Number(candles[i - 1].low) - Number(candles[i].low);
      plusDM[i] = up > down && up > 0 ? up : 0;
      minusDM[i] = down > up && down > 0 ? down : 0;
      tr[i] = Math.max(
        Number(candles[i].high) - Number(candles[i].low),
        Math.abs(Number(candles[i].high) - Number(candles[i - 1].close)),
        Math.abs(Number(candles[i].low) - Number(candles[i - 1].close))
      );
    }

    let smoothTR = tr.slice(1, period + 1).reduce((a, b) => a + b, 0);
    let smoothPlus = plusDM.slice(1, period + 1).reduce((a, b) => a + b, 0);
    let smoothMinus = minusDM.slice(1, period + 1).reduce((a, b) => a + b, 0);
    const dx = Array(length).fill(null);

    for (let i = period; i < length; i++) {
      if (i > period) {
        smoothTR = smoothTR - smoothTR / period + tr[i];
        smoothPlus = smoothPlus - smoothPlus / period + plusDM[i];
        smoothMinus = smoothMinus - smoothMinus / period + minusDM[i];
      }
      plusDI[i] = smoothTR ? 100 * smoothPlus / smoothTR : 0;
      minusDI[i] = smoothTR ? 100 * smoothMinus / smoothTR : 0;
      const denom = plusDI[i] + minusDI[i];
      dx[i] = denom ? 100 * Math.abs(plusDI[i] - minusDI[i]) / denom : 0;
    }

    const firstADX = period * 2 - 1;
    let seed = dx.slice(period, firstADX + 1);
    if (seed.length === period && seed.every(Number.isFinite)) {
      let value = seed.reduce((a, b) => a + b, 0) / period;
      adxLine[firstADX] = value;
      for (let i = firstADX + 1; i < length; i++) {
        value = ((value * (period - 1)) + dx[i]) / period;
        adxLine[i] = value;
      }
    }
    return { adx: adxLine, plusDI, minusDI };
  }

  function calculate(candles) {
    const closes = candles.map(c => Number(c.close));
    const macdValues = macd(closes);
    const bb = bollinger(closes);
    const adxValues = adx(candles);
    const rsiValues = rsi(closes);
    const ema9 = ema(closes, 9), ema21 = ema(closes, 21), ema50 = ema(closes, 50);
    const atrValues = atr(candles);
    const last = closes.length - 1;
    return {
      price: closes[last],
      rsi: rsiValues[last],
      macd: macdValues.line[last],
      macdSignal: macdValues.signal[last],
      macdHistogram: macdValues.histogram[last],
      ema9: ema9[last], ema21: ema21[last], ema50: ema50[last],
      adx: adxValues.adx[last], plusDI: adxValues.plusDI[last], minusDI: adxValues.minusDI[last],
      atr: atrValues[last],
      bollingerUpper: bb.upper[last], bollingerMiddle: bb.middle[last], bollingerLower: bb.lower[last]
    };
  }

  global.CryptoIndicators = { sma, ema, rsi, macd, bollinger, atr, adx, calculate };
})(window);
