/* Crypto Futures Screener - Dashboard app
   Reads docs/signals.csv. This file does not fetch exchange data by itself.
   CSV columns recommended: symbol,price,signal,rsi,adx,macd,emaTrend,volume,updatedAt
*/
(function () {
  "use strict";

  const CSV_PATH = "signals.csv";
  const REFRESH_MS = 60000;
  const $ = (selector) => document.querySelector(selector);
  const state = { rows: [], search: "", signal: "ALL", lastLoaded: null };

  function parseCSV(text) {
    const lines = text.trim().split(/\r?\n/).filter(Boolean);
    if (lines.length < 2) return [];
    const splitLine = (line) => {
      const cells = [];
      let current = "", quoted = false;
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"' && line[i + 1] === '"' && quoted) { current += '"'; i++; }
        else if (char === '"') quoted = !quoted;
        else if (char === "," && !quoted) { cells.push(current.trim()); current = ""; }
        else current += char;
      }
      cells.push(current.trim());
      return cells;
    };
    const headers = splitLine(lines[0]).map(h => h.replace(/^\uFEFF/, "").toLowerCase());
    return lines.slice(1).map(line => {
      const values = splitLine(line);
      return headers.reduce((row, key, index) => {
        row[key] = values[index] ?? "";
        return row;
      }, {});
    }).filter(row => row.symbol || row.coin);
  }

  function fmt(value, digits = 2) {
    const number = Number(value);
    return value === "" || value == null || !Number.isFinite(number) ? "—" :
      number.toLocaleString(undefined, { maximumFractionDigits: digits });
  }

  function normalSignal(row) {
    const value = String(row.signal || "NEUTRAL").toUpperCase();
    if (value.includes("BULL") || value === "LONG" || value === "BUY") return "BULLISH";
    if (value.includes("BEAR") || value === "SHORT" || value === "SELL") return "BEARISH";
    return "NEUTRAL";
  }

  function safe(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[ch]));
  }

  function render() {
    const tbody = $("#signals-body") || $("tbody");
    if (!tbody) return;
    const filtered = state.rows.filter(row => {
      const symbol = String(row.symbol || row.coin || "").toLowerCase();
      const signal = normalSignal(row);
      return symbol.includes(state.search) && (state.signal === "ALL" || signal === state.signal);
    });

    tbody.innerHTML = filtered.map(row => {
      const symbol = row.symbol || row.coin || "—";
      const signal = normalSignal(row);
      const cls = signal.toLowerCase();
      return `<tr>
        <td>${safe(symbol)}</td>
        <td>${fmt(row.price, 6)}</td>
        <td><span class="signal ${cls}">${signal}</span></td>
        <td>${fmt(row.rsi)}</td>
        <td>${fmt(row.adx)}</td>
        <td>${safe(row.macd || "—")}</td>
        <td>${safe(row.emaTrend || row.ematrend || "—")}</td>
        <td>${fmt(row.volume, 0)}</td>
      </tr>`;
    }).join("");

    const count = $("#result-count");
    if (count) count.textContent = `${filtered.length} results`;
    const updated = $("#last-updated");
    if (updated) updated.textContent = state.lastLoaded ? `Updated ${state.lastLoaded.toLocaleTimeString()}` : "Not updated yet";
    const empty = $("#empty-state");
    if (empty) empty.hidden = filtered.length > 0;
  }

  async function loadSignals() {
    const refresh = $("#refresh-btn");
    if (refresh) refresh.disabled = true;
    try {
      const response = await fetch(`${CSV_PATH}?t=${Date.now()}`, { cache: "no-store" });
      if (!response.ok) throw new Error(`CSV load failed: HTTP ${response.status}`);
      state.rows = parseCSV(await response.text());
      state.lastLoaded = new Date();
      render();
    } catch (error) {
      console.error(error);
      const status = $("#last-updated");
      if (status) status.textContent = "Could not load signals.csv";
    } finally {
      if (refresh) refresh.disabled = false;
    }
  }

  function wireControls() {
    const search = $("#search-input") || $("#search");
    if (search) search.addEventListener("input", event => {
      state.search = event.target.value.trim().toLowerCase();
      render();
    });
    const signal = $("#signal-filter");
    if (signal) signal.addEventListener("change", event => {
      state.signal = event.target.value.toUpperCase();
      render();
    });
    const refresh = $("#refresh-btn");
    if (refresh) refresh.addEventListener("click", loadSignals);
  }

  function init() {
    wireControls();
    loadSignals();
    window.setInterval(loadSignals, REFRESH_MS);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
