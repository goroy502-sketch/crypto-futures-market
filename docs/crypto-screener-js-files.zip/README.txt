# Separate JavaScript files

Upload these two files to your GitHub repository:
- `docs/js/app.js`
- `docs/js/indicators.js`

Important:
- Your `docs/index.html` should load both files near the end of the page:
  `<script src="js/indicators.js"></script>`
  `<script src="js/app.js"></script>`
- The dashboard app expects `docs/signals.csv`.
- `app.js` reads CSV only; it does not connect to an exchange or create live signals.
- The HTML table should have columns for Coin, Price, Signal, RSI, ADX, MACD, EMA Trend, and Volume. Give the table body `id="signals-body"`.
